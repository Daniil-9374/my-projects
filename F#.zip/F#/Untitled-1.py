lrc = 0
for bit in "C20000000000001000\x03":
    lrc = lrc ^ ord(bit)
    print(ord(bit))
print(lrc)