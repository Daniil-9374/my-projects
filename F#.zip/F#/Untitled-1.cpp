int lrc = 0;
for (auto bit : "C20000000000001000\x03")
lrc = lrc XOR bit;
printf("hello");
//return lrc;